<?php $__env->startSection('body'); ?>
    <div class="content-wrapper">

        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Add Tag - Criar Lista de Audiência</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Uplista</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="title">Selecione o Arquivo em CSV</h3>
                                <br>
                                <p><span>Será atribuído uma tag com nome sugerido, serve como conceito de lista na segmentação</span></p>
                                <p class="card-text">
                                    <form action="<?php echo e(route('pegaArquivo')); ?>" method="post" enctype="multipart/form-data">
                                        <input type="text" name="tag" class="col-lg-6"placeholder="Digite nome da Tag"/>
                                        <input type="file" name="arquivo">
                                        <?php echo csrf_field(); ?> <!-- <?php echo e(csrf_field()); ?> -->
                                        ...
                                        <button type="submit" name="submit" class="btn btn-success btn-block mt-4">
                                            Subir Lista 
                                        </button>
                                    </form>
                                </p>
                            
                            </div>
                        </div>
                        
                    </div>



                    <div class="col-lg-4">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">CallBack</h5>
                                <p class="card-text">
                                    
                                  
                                </p>
                            
                            </div>
                        </div>
                        
                    </div>

                </div>

            </div>
        </div>

    </div>

    
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor/adminlte/master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/ludsonalmeida/Documents/www/laravel55/resources/views/vendor/adminlte/uplista.blade.php ENDPATH**/ ?>